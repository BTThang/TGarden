package com.example.tgarden.User;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tgarden.R;

public class UserDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);
    }
}