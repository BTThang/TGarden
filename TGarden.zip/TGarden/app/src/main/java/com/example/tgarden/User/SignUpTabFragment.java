package com.example.tgarden.User;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tgarden.R;

public class SignUpTabFragment extends Fragment {

    EditText email_sign, password_sign, phone, confirm;
    Button button_signup;
    float v = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.signup_tab_fragment, container, false);

        email_sign = root.findViewById(R.id.Email_signup);
        password_sign = root.findViewById(R.id.password_sign);
        phone = root.findViewById(R.id.phone_number);
        confirm = root.findViewById(R.id.confirm);
        button_signup = root.findViewById(R.id.button_signup);


        email_sign.setTranslationX(800);
        password_sign.setTranslationX(800);
        phone.setTranslationX(800);
        confirm.setTranslationX(800);
        button_signup.setTranslationX(800);

        email_sign.setAlpha(v);
        password_sign.setAlpha(v);
        phone.setAlpha(v);
        confirm.setAlpha(v);
        button_signup.setAlpha(v);

        email_sign.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        password_sign.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        phone.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        confirm.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        button_signup.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();


        return root;
//        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
